RNG Adventure v1.00.33 — Render WebSocket Backend

Browser-only setup:
1. Create a GitHub repository named rng-adventure-backend.
2. In GitHub, use Add file -> Upload files and upload server.py.
3. On Render, create New -> Web Service and connect the GitHub repository.
4. Runtime/language: Python.
5. Build Command: leave blank (this server uses only Python's standard library).
6. Start Command: python server.py
7. Deploy.
8. Render gives you a URL such as https://rng-adventure-backend.onrender.com
9. The game WebSocket URL will be:
   wss://rng-adventure-backend.onrender.com

Important:
- This backend includes the v1.00.33 rare-drop announcements and admin-target controls.
- The server keeps player state in memory, so a service restart resets currently connected players.
- Render free services can spin down after inactivity; they wake when a new connection/request arrives.
- Never put admin keys in the website code.
